"""L1-SEM-ANCHOR-02 离线预检与锚定测试。"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from tests.conftest import ROOT, dimension_semantic_fields
from 语义证据校验 import (
    REQUIRED_DIMENSIONS,
    SCOPE_CURRENT,
    校验exact_text协议,
    校验语义审计响应,
    摘句在正文中,
)

EXEC = ROOT / "00_工程总控" / "工程执行层"
L1_SEM = EXEC / "L1工程" / "L1_语义审计.py"


def _dim(name: str, quote: str, *, pid: str = "P0001", verdict: str = "REVIEW") -> dict:
    fields = dimension_semantic_fields(name, verdict)
    return {
        "name": name,
        "verdict": verdict,
        **fields,
        "evidence": [
            {
                "paragraph_id": pid,
                "exact_text": quote,
                "source_scope": SCOPE_CURRENT,
                "occurrence_index": 0,
                "evidence_rationale": f"该摘句作为{name}维度的代表性锚点，支持 strength_summary，不等同于整章证明。",
            }
        ],
    }


def _full(quote: str, **kwargs) -> dict:
    return {"dimensions": [_dim(n, quote, **kwargs) for n in REQUIRED_DIMENSIONS]}


def test_代码块单行证据通过():
    text = "```\n【补充数据】\n这座大楼的建筑设计图，在规划局没有备案。\n一次都没有。\n```"
    corpus = {"P0079": text}
    assert 校验语义审计响应(_full("这座大楼的建筑设计图，在规划局没有备案。", pid="P0079"), current_paragraphs=corpus).ok


def test_代码块删除换行拼接拒绝():
    text = "```\n【补充数据】\n这座大楼的建筑设计图，在规划局没有备案。\n一次都没有。\n```"
    corpus = {"P0079": text}
    r = 校验语义审计响应(_full("备案。一次都没有。", pid="P0079"), current_paragraphs=corpus)
    assert not r.ok


def test_多行证据拆分为多个item通过():
    text = "```\n【补充数据】\n这座大楼的建筑设计图，在规划局没有备案。\n一次都没有。\n```"
    corpus = {"P0079": text}
    dims = []
    for name in REQUIRED_DIMENSIONS:
        fields = dimension_semantic_fields(name, "REVIEW")
        ev = [
            {
                "paragraph_id": "P0079",
                "exact_text": "这座大楼的建筑设计图，在规划局没有备案。",
                "source_scope": SCOPE_CURRENT,
                "occurrence_index": 0,
                "evidence_rationale": "第一条单行证据。",
            },
            {
                "paragraph_id": "P0079",
                "exact_text": "一次都没有。",
                "source_scope": SCOPE_CURRENT,
                "occurrence_index": 0,
                "evidence_rationale": "第二条单行证据。",
            },
        ]
        dims.append({"name": name, "verdict": "REVIEW", **fields, "evidence": ev})
    r = 校验语义审计响应({"dimensions": dims}, current_paragraphs=corpus)
    assert r.ok
    assert len(r.validated_evidence) == 12


def test_直引号原文通过():
    corpus = {"P0001": '"走了。"小刘抬头。'}
    assert 摘句在正文中('"走了。"', corpus["P0001"])
    assert 校验语义审计响应(_full('"走了。"', pid="P0001"), current_paragraphs=corpus).ok


def test_弯引号替换拒绝():
    corpus = {"P0001": '"走了。"小刘抬头。'}
    assert not 摘句在正文中("\u201c走了。\u201d", corpus["P0001"])


def test_省略号截断拒绝():
    assert 校验exact_text协议("陈敛关掉IDE...") is not None


def test_final_reason缺固定词但结构字段完整不阻断():
    corpus = {"P0001": "他必须做出选择，否则代价会落在所有人身上。"}
    payload = _full("他必须做出选择")
    for dim in payload["dimensions"]:
        if dim["name"] == "因果":
            dim["verdict"] = "PASS"
            dim["final_reason"] = "全章事件增量清晰：准点下班（起因）→系统收割（结果）→匿名信（新起因）"
            dim["analysis_summary"] = "主要优点：链条连续；主要风险：无；最终选择 PASS 因为随后主角做出选择并推进。"
    r = 校验语义审计响应(payload, current_paragraphs=corpus)
    assert r.ok


def test_结构化因果字段缺失仍阻断():
    corpus = {"P0001": "天气很好。"}
    payload = _full("天气很好")
    for dim in payload["dimensions"]:
        if dim["name"] == "因果":
            dim["verdict"] = "PASS"
            dim["final_reason"] = "情节清晰，容易理解。"
            dim["analysis_summary"] = "主要优点：无；主要风险：无因果；最终 PASS。"
    r = 校验语义审计响应(payload, current_paragraphs=corpus)
    assert not r.ok


def test_证据无效时失败包为空():
    r = 校验语义审计响应(_full("不存在"), current_paragraphs={"P0001": "真实正文"})
    assert not r.ok
    assert r.validated_evidence == []


def test_证据有效时解除EVIDENCE_INVALID():
    corpus = {"P0001": "他必须做出选择，否则代价会落在所有人身上。"}
    r = 校验语义审计响应(_full("他必须做出选择"), current_paragraphs=corpus)
    assert r.ok
    assert len(r.validated_evidence) == 6


@pytest.mark.parametrize(
    "needle",
    [
        "exact_text 不得跨越换行符",
        "代码块证据正确示例",
        "code_block_evidence_forbidden",
        "禁止原因",
        "不得将正文直引号",
    ],
)
def test_prompt_预检(needle: str):
    text = L1_SEM.read_text(encoding="utf-8")
    assert needle in text or "不得跨越换行符" in text
